{
	"surrogates": {

		"1": "var urchinTracker=function(){},_gaq={push:function(){try {if(arguments[0][0]=='_link')window.location.href=arguments[0][1]}catch(er){}}},_gat={_createTracker:function(){}, _getTracker:function(){return{__noSuchMethod__:function(){},_link:function(o){if(o)location.href=o;},_linkByPost:function(){return true;},_getLinkerUrl:function(o){return o;},_trackEvent:function(){}}}};",

		"2": "var _ga_ = document.querySelectorAll('script[src$=ga\\\\.js]')[0], ga_e = document.createEvent('Event'); ga_e.initEvent('load', true, true);_ga_.dispatchEvent(ga_e);",
		
		"3": "var COMSCORE={beacon:function(){},purge:function(){},__noSuchMethod__:function(){}}",

		"4": "var SavePageView=function(){},GetQueryStringValue=function(qs){if(qs=='freewheel')return'';var qs=qs.replace(/[\\[]/,\"\\\\\\[\").replace(/[\\]]/,\"\\\\\\]\");var regexS=\"[\\\\?&]\"+qs.toLowerCase()+'=([^&#]*)';var regex=new RegExp(regexS);var results=regex.exec(window.location.href.toLowerCase());if(results==null){return'';}else{return results[1];}}",

		"5": "var YWA={getTracker:function(){return{__noSuchMethod__:function(){}}},__noSuchMethod__:function(){}}",

		"6": "function omn_rmaction() {}",

		"7": "function geoip_country_code(){return 'A1';};function geoip_country_name(){return 'Anonymous Proxy';}",

		"8": "var geoip_city=geoip_region=geoip_region_name=geoip_latitude=geoip_longitude=geoip_postal_code=geoip_area_code=geoip_metro_code=function() { return; }",

		"9": "function _ghost(){return{record:function(){return{post:function(){}}},slideEvent:function(){}}};var nol_t=function(){return new _ghost();}",

		"10": "function wt_sendinfo(){};",

		"11": "function mktoMunchkinFunction(){}",

		"12": "var SHARETHIS={__noSuchMethod__:function(){},addEntry:function(){return {__noSuchMethod__:function(){}} }}",

		"13": "var addthis={init:function(){}, toolbox:function(){}, button:function(){}, counter:function(){}};",

		"14": "var DM_addEncToLoc=function(){},DM_tag=function(){};",

		"15": "function SmartAdServer(){sas_noad=true;};",

		"16": "var _cm = function() {};_cm.prototype = function () {};_cm.prototype.addTP = function () {};_cm.prototype.writeImg = function (){};function cmSmartTagSet() {};function cmStartTagSet() {};function cmSendTagSet() {}; var cI = function(){};",

		"17": "var ATGSvcs={l10n:{register:function(){}},rec_builder:function(){}};",

		"18": "var Ya=Ya||{};Ya.share=function(){var API={};API.updateCustomService=API.updateShareLink=function(){};return API;};",

		"19": "function geoplugin_request(){return '0.0.0.0';};function geoplugin_status(){return '404';};var geoplugin_city=geoplugin_region=geoplugin_regionCode=geoplugin_regionName=geoplugin_areaCode=geoplugin_dmaCode=geoplugin_countryCode=geoplugin_countryName=geoplugin_continentCode=geoplugin_latitude=geoplugin_longitude=function(){return'';}",

		"20": "FB={Event:{subscribe:function(){}},UIServer:{},XFBML:{parse:function(){}},init:function(){},__noSuchMethod__:function(){}};",

		"21": "var fb = document.querySelectorAll('script[src$=connect\\\\.facebook\\\\.net\\\\/en_US\\\\/all\\\\.js]')[0], le = document.createEvent('Event');le.initEvent('load', true, true);fb.dispatchEvent(le);",

		"22": "function dcsMultiTrack(){};function WebTrends(){return{dcsMultiTrack:function(){},__noSuchMethod__:function(){},DCS:{__noSuchMethod__:function(){}},WT:{__noSuchMethod__:function(){}},DCSext:{__noSuchMethod__:function(){}}}};",

		"23": "function _hbRedirect(a,b,c){location.href=c};var _hbLink=function(){}",

		"24": "function mboxCreate(){}; function mboxTrack(){return true;}; function mboxTrackLink(){}",

		"25": "var s={__noSuchMethod__:function(){},Media:{__noSuchMethod__:function(){}}}; function s_gi(){return s;}",

		"26": "var s={__noSuchMethod__:function(){},t:function(){},tl:function(){},pageName:'',Media:{__noSuchMethod__:function(){}}}; function s_gi(){return s;} function setProductsIntoCookie(){} function customProductTabTracker(){};var s_analytics=s,s_account='';",

		"27": "var s_time=s={__noSuchMethod__:function(){},Media:{__noSuchMethod__:function(){}}}; function s_gi(){return s;} function setProductsIntoCookie(){} function customProductTabTracker(){};var s_analytics=s,s_account='';function s_beginCheckout(){};",

		"28": "AC.Tracking.pageName=function(){};"

	},

	"mappings": [

		{
			"app_id": 13,
			"sid": 1
		},

		{
			"pattern_id": 2,
			"match": "http://www.google-analytics.com/ga.js",
			"sites": "www.salon.com",
			"sid": 2
		},

		{
			"pattern_id": 181,
			"sid": 3
		},

		{
			"pattern_id": 526,
			"sid": 4
		},

		{
			"pattern_id": 18,
			"sid": 5
		},

		{
			"pattern_id": 1036,
			"match": "https://www.aexp-static.com/api/axpi/omniture/s_code.js",
			"sid": 6
		},

		{
			"pattern_id": 1548,
			"sid": 7
		},

		{
			"pattern_id": 1548,
			"match": "http://j.maxmind.com/app/geoip.js",
			"sid": 8
		},

		{
			"pattern_id": 34,
			"sid": 9
		},

		{
			"pattern_id": 468,
			"sid": 10
		},

		{
			"pattern_id": 159,
			"sid": 11
		},

		{
			"pattern_id": 41,
			"sid": 12
		},

		{
			"pattern_id": 44,
			"sid": 13
		},

		{
			"pattern_id": 1053,
			"sid": 14
		},

		{
			"pattern_id": 982,
			"sid": 15
		},

		{
			"pattern_id": 163,
			"sid": 16
		},

		{
			"pattern_id": 679,
			"sid": 17
		},

		{
			"pattern_id": 1127,
			"sid": 18
		},

		{
			"pattern_id": 1751,
			"sid": 19
		},

		{
			"pattern_id": 1027,
			"sid": 20
		},

		{
			"pattern_id": 1027,
			"sites": "news.yahoo.com",
			"sid": 21
		},

		{
			"pattern_id": [1045, 39],
			"sid": 22
		},

		{
			"pattern_id": 1036,
			"match": "\\/hbx(.*)?\\.js",
			"sid": 23
		},

		{
			"pattern_id": 1036,
			"match": "\\/(mbox)(.*)?\\.js",
			"sid": 24
		},

		{
			"pattern_id": 1036,
			"match": ["new.evite.com/js/omniture", "http://o.aolcdn.com/os/omniture/prod/omniunih_portal_min.js"],
			"sid": 25
		},

		{
			"pattern_id": 1037,
			"sid": 26
		},

		{
			"pattern_id": 1036,
			"match": "\\/(omniture|omniunih)(.*)?\\.js",
			"sid": 27
		},

		{
			"sites": ["store.apple.com", "www.apple.com"],
			"sid": 26
		},

		{
			"pattern_id": 1037,
			"sites": "www.apple.com",
			"sid": 28
		}

	],

	"version": 1
}
