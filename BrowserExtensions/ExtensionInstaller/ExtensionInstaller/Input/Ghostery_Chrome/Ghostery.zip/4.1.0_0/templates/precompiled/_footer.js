var __templates=__templates||{};
__templates["_footer"]=function(obj){
var __p='';var print=function(){__p+=Array.prototype.join.call(arguments, '')};
with(obj||{}){
__p+='<div id="footer" role="contentinfo">\n\t'+
( t("copyright") )+
'\n</div>\n';
}
return __p;
};